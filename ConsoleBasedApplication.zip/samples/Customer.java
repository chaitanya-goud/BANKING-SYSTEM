import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


class Customer extends User {
    private List<Account> accounts;
    private static Set<String> existingAccountNumbers = new HashSet<>();
    double min = 0;
    double initialDeposit = 0;
    private List<Loan> loans = new ArrayList<>();

    

    public Customer(String username, String password) {
        super(username, password);
        this.accounts = new ArrayList<>();
    }
    public String getUsername() {
        return this.username;
    }
    
    public void createSavingsAccount(String accountNumber, double interestRate,double minimumBalance) {
        if (!existingAccountNumbers.add(accountNumber)) {
            System.out.println("Account number already exists. Choose a different number.");
            return;
        }
        accounts.add(new SavingsAccount(accountNumber, interestRate,minimumBalance));
        System.out.println("Savings account created with account number: " + accountNumber);
    }

    public void createFixedAccount(String accountNumber, int term,double initialDeposit) {
        if (!existingAccountNumbers.add(accountNumber)) {
            System.out.println("Account number already exists. Choose a different number.");
            return;
        }
        accounts.add(new FixedAccount(accountNumber, term,initialDeposit));
        System.out.println("Fixed account created with account number: " + accountNumber);
    }

    public void createCurrentAccount(String accountNumber, double overdraftLimit,double initialDeposit) {
        if (!existingAccountNumbers.add(accountNumber)) {
            System.out.println("Account number already exists. Choose a different number.");
            return;
        }
        accounts.add(new CurrentAccount(accountNumber, overdraftLimit));
        System.out.println("Current account created with account number: " + accountNumber);
    }

    public List<Account> getAccounts() {
        return accounts;
    }

    public void viewBalance(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                System.out.println("Balance for account " + accountNumber + ": " + account.getBalance());
                return;
            }
        }
        System.out.println("Account not found.");
    }

    public void deposit(String accountNumber, double amount) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                account.deposit(amount);
                System.out.println("Deposited " + amount + " to account " + accountNumber);
                return;
            }
        }
        System.out.println("Account not found.");
    }

    public void withdraw(String accountNumber, double amount) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                account.withdraw(amount);
                return;
            }
        }
        System.out.println("Account not found.");
    }

    public void viewTransactionHistory(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                System.out.println("Transaction history for account " + accountNumber + ":");
                for (Transaction transaction : account.getTransactions()) {
                    System.out.println(transaction);
                }
                return;
            }
        }
        System.out.println("Account not found.");
    }
    public boolean closeAccount(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                accounts.remove(account);
                System.out.println("Account " + accountNumber + " has been successfully closed.");
                return true;
            }
        }
        System.out.println("Account not found.");
        return false;
    }
    public void viewAccountDetails() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts found.");
        } else {
            System.out.println("Account Details:");
            for (Account account : accounts) {
                System.out.println("-------------------------");
                System.out.println("Account Number: " + account.getAccountNumber());
                System.out.println("Account Type: " + account.getAccountType());
                System.out.println("Balance: " + account.getBalance());
            }
            System.out.println("-------------------------");
        }
    }
    public Account getAccount(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;
            }
        }
        return null;  // If account is not found
    }
    public String getPassword() {
        return this.password;  // Assuming `password` is a field in the `User` class
    }
    // In Customer class
    public void transferLoanToAccount(String loanId) {
        Loan loan = findLoanById(loanId);  // Find the loan by its ID
        if (loan != null) {
            double loanAmount = loan.getLoanAmount();
            
            // Check if the customer has any accounts
            if (accounts.isEmpty()) {
                System.out.println("No accounts available to transfer the loan to.");
            } else {
                // Assuming the customer wants to transfer to the first account in the list
                Account account = accounts.get(0);  // You can modify this to choose a specific account
                account.deposit(loanAmount);  // Deposit the loan amount to the account
                System.out.println("Loan amount of " + loanAmount + " has been transferred to account " + account.getAccountNumber());
            }
        } else {
            System.out.println("Loan not found.");
        }
    }
    
// In Customer class
public void repayLoan(String loanId, double amount) {
    Loan loan = findLoanById(loanId);
    if (loan != null) {
        if (amount > 0) {
            loan.makePayment(amount);
            System.out.println("Payment of " + amount + " has been made. Remaining loan balance: " + loan.getRemainingBalance());
        } else {
            System.out.println("Invalid payment amount.");
        }
    } else {
        System.out.println("Loan not found.");
    }
}
public Loan findLoanById(String loanId) {
    for (Loan loan : loans) {
        if (loan.getLoanId().equals(loanId)) {
            return loan;
        }
    }
    return null;  // Return null if loan with the given ID is not found
}
public void viewAllLoans() {
    if (loans.isEmpty()) {
        System.out.println("No loans found.");
    } else {
        System.out.println("Customer Loans:");
        for (Loan loan : loans) {
            loan.viewLoanDetails();
            System.out.println("-------------------------");
        }
    }
}
// Close a loan when it's fully paid off
public void closeLoan(String loanId) {
    Loan loan = findLoanById(loanId);  // Find the loan by ID
    if (loan != null) {
        loan.closeLoan();  // Close the loan (no arguments needed)
        if (loan.getRemainingBalance() == 0) {
            loans.remove(loan);  // Remove the loan from the list if it's fully paid off
            System.out.println("Loan " + loanId + " has been successfully closed.");
        } else {
            System.out.println("Loan still has a remaining balance and cannot be closed.");
        }
    } else {
        System.out.println("Loan with ID " + loanId + " not found.");
    }
}

public void makeLoanPayment(String loanId, double amount) {
    Loan loan = findLoanById(loanId);
    if (loan != null) {
        loan.makePayment(amount);
    } else {
        System.out.println("Loan with ID " + loanId + " not found.");
    }
}
 // Add a loan to the customer's loan list
 public void createLoan(String loanId, double loanAmount, double interestRate, int loanTermInYears, Date startDate) {
    Loan newLoan = new Loan(loanId, loanAmount, interestRate, loanTermInYears, startDate);
    loans.add(newLoan);
    System.out.println("Loan created with ID: " + loanId);
}
public void viewLoanDetails(String loanId) {
    Loan loan = findLoanById(loanId);
    if (loan != null) {
        loan.viewLoanDetails();
    } else {
        System.out.println("Loan with ID " + loanId + " not found.");
    }
}



}

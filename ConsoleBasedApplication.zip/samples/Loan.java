import java.util.Date;
import java.util.List;

public class Loan {
    private String loanId;
    private double loanAmount;
    private double interestRate;
    private int loanTermInYears;
    private Date startDate;
    private double remainingBalance;
    private double totalAmountToPay;
      private static List<Loan> loans;

    // Constructor and other methods...

    public Loan(String loanId, double loanAmount, double interestRate, int loanTermInYears, Date startDate) {
        this.loanId = loanId;
        this.loanAmount = loanAmount;
        this.interestRate = interestRate;
        this.loanTermInYears = loanTermInYears;
        this.startDate = startDate;
        this.totalAmountToPay = calculateTotalAmountToPay();
        this.remainingBalance = totalAmountToPay;
    }
    public void closeLoan(String loanId) {
        Loan loan = findLoanById(loanId);
        if (loan != null && loan.getRemainingBalance() == 0) {
            loans.remove(loan);
            System.out.println("Loan " + loanId + " is successfully closed.");
        } else {
            System.out.println("Loan either doesn't exist or still has an outstanding balance.");
        }
    }
    

    // Calculate total amount to pay (loan amount + interest over the term)
    private double calculateTotalAmountToPay() {
        double totalInterest = (loanAmount * interestRate * loanTermInYears) / 100;
        return loanAmount + totalInterest;
    }
    // Method to create a loan
public void createLoan(String loanId, double loanAmount, double interestRate, int loanTermInYears, Date startDate) {
    Loan newLoan = new Loan(loanId, loanAmount, interestRate, loanTermInYears, startDate);
    loans.add(newLoan);
    System.out.println("Loan created with ID: " + loanId);
}


    

    // Method to view loan details
    // In Loan class
public void viewLoanDetails() {
    System.out.println("Loan ID: " + loanId);
    System.out.println("Loan Amount: " + loanAmount);
    System.out.println("Interest Rate: " + interestRate + "%");
    System.out.println("Loan Term (years): " + loanTermInYears);
    System.out.println("Start Date: " + startDate);
    System.out.println("Total Amount to Pay: " + totalAmountToPay);
    System.out.println("Remaining Balance: " + remainingBalance);
    // Optionally, print payment history (if you add a list of payments in the Loan class)
}


    // Getters for loan fields
    public String getLoanId() {
        return loanId;
    }

    public double getRemainingBalance() {
        return remainingBalance;
    }
    public double getLoanAmount() {
        return loanAmount;
    }
    public void makePayment(double amount) {
        if (amount > 0 && amount <= remainingBalance) {
            remainingBalance -= amount;
            System.out.println("Payment of " + amount + " made successfully. Remaining balance: " + remainingBalance);
        } else {
            System.out.println("Invalid payment amount. Please check and try again.");
        }
    }
    public void closeLoan() {
        if (remainingBalance == 0) {
            System.out.println("Loan " + loanId + " has been successfully closed.");
        } else {
            System.out.println("Loan has a remaining balance and cannot be closed.");
        }
    }
    public static Loan findLoanById(String loanId) {
        for (Loan loan : loans) {
            if (loan.getLoanId().equals(loanId)) {
                return loan;
            }
        }
        return null; // Return null if no loan with the given loanId is found
    }


}

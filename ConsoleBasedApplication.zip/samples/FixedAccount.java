import java.util.Calendar;
import java.util.Date;

class FixedAccount extends Account {
    private final int termInYears;
    private Date maturityDate;

    public FixedAccount(String accountNumber, int termInYears, double initialDeposit) {
        super(accountNumber);
        this.termInYears = termInYears;
        deposit(initialDeposit); // Initial deposit at account creation
        setMaturityDate(); // Set the maturity date based on term
    }

    private void setMaturityDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, termInYears);
        this.maturityDate = calendar.getTime();
    }

    @Override
    public void withdraw(double amount) {
        Date currentDate = new Date();
        if (currentDate.after(maturityDate)) {
            if (amount <= getBalance()) {
                Transaction transaction = new Transaction(getAccountNumber(), "Withdrawal", amount);
                getTransactions().add(transaction);
                System.out.println("Withdrawal successful: " + amount);
            } else {
                System.out.println("Insufficient funds for withdrawal.");
            }
        } else {
            System.out.println("Withdrawal not allowed before maturity date: " + maturityDate);
        }
    }

    @Override
    public void accountDetails() {
        System.out.println("Fixed Account Number: " + getAccountNumber());
        System.out.println("Balance: " + getBalance());
        System.out.println("Term (years): " + termInYears);
        System.out.println("Maturity Date: " + maturityDate);
    }

    public int getTermInYears() {
        return termInYears;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }
    @Override
    public String getAccountType() {
        return "Fixed Account";
    }
}
